

fun main(){
    val name = "Dilfuza"
    val surname = "Tursunbekva"

    val combined = name + surname
    println(combined)
}
